﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pratico
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;

        private void txtnum2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(txtnum2, "");
                numero2 = Convert.ToDouble(txtnum2.Text);
            }
            catch
            {
                errorProvider2.SetError(txtnum2, "Número 2 Inválido");
                txtnum2.Focus();
            }
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtresult.Text = resultado.ToString();
        }

        private void btnsub_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtresult.Text = resultado.ToString();
        }

        private void btnmult_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtresult.Text = resultado.ToString();
        }

        private void btndiv_Click(object sender, EventArgs e)
        {
            if(numero2 == 0)
            {
                errorProvider2.SetError(txtnum2, "Não pode ser 0");
            }
            else
            {
                resultado = numero1 / numero2;
                txtresult.Text = resultado.ToString();
            }
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtnum1.Text = txtnum2.Text = txtresult.Text = "";
            numero1 = numero2 = resultado = 0;
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Deseja realmente sair?", "Fechar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }
                        
         
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtnum1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtnum1.Text, out numero1))
            {
                errorProvider1.SetError(txtnum1, "Número 1 inválido");
                txtnum1.Focus();
            }
            else
                errorProvider1.SetError(txtnum1, "");
        }
    }
}
