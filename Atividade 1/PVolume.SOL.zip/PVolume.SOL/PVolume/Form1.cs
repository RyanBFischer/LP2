﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        Double raio, altura, volume;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblRaio_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtVolume_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Text = "";
            txtRaio.Text = "";
            txtVolume.Clear();
        }

        private void txtAltura_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out altura)
            || (altura <= 0))
            {
                MessageBox.Show("Altura inválida");
            }
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
          if  (!Double.TryParse(txtRaio.Text, out raio)
                || (raio <= 0))
            {
                MessageBox.Show("Raio Inválido");
                txtRaio.Focus();
            }
          else if (!Double.TryParse(txtAltura.Text, out altura)
                || (altura <= 0))
            {
                MessageBox.Show("Altura Inválida");
                txtAltura.Focus();
            }
          else
            {
                volume = Math.PI * Math.Pow(raio, 2) * altura;
                txtVolume.Text = volume.ToString("N2");
            }
        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text, out raio)
                || (raio <= 0))
            {
                MessageBox.Show("Raio Inválido");
            }
        }
    }
}
