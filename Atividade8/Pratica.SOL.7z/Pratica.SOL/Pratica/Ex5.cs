﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pratica
{
    public partial class Ex5 : Form
    {
        public Ex5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int N = 7;
            int Q = 10;

            char[] gabarito = { 'A', 'B', 'C', 'D', 'E', 'A', 'B', 'C', 'D', 'E' };

            char[,] respostas = new char[N, Q];

            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < Q; j++)
                {
                    string entrada;
                    do
                    {
                        entrada = Interaction.InputBox(
                            $"Aluno {i + 1} - Questão {j + 1} (A, B, C, D ou E):",
                            "Resposta do Aluno").ToUpper().Trim();
                    }
                    while (entrada.Length != 1 || !"ABCDE".Contains(entrada));

                    respostas[i, j] = entrada[0];
                }
            }

            for (int i = 0; i < N; i++)
            {
                int acertos = 0;
                for (int j = 0; j < Q; j++)
                {
                    if (respostas[i, j] == gabarito[j])
                        acertos++;
                }

                listBox1.Items.Add($"Aluno {i + 1}: {acertos} acertos de {Q}");
            }
        }
    }
}
