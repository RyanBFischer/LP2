﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pratica
{
    public partial class Ex4 : Form
    {
        public Ex4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            int[] tamanhos = new int[10];

            for (int i = 0; i < 10; i++)
            {
                string nome;
                do
                {
                    nome = Microsoft.VisualBasic.Interaction.InputBox(
                        $"Digite o nome completo da pessoa {i + 1}:",
                        "Entrada de Nome");

                    nome = nome.Trim();

                } while (string.IsNullOrWhiteSpace(nome));

                nomes[i] = nome;
                tamanhos[i] = nome.Replace(" ", "").Length;
            }

            for (int i = 0; i < 10; i++)
            {
                listBox1.Items.Add($"{nomes[i]} - {tamanhos[i]} caracteres (sem espaços)");
            }
        }
    }
}
        