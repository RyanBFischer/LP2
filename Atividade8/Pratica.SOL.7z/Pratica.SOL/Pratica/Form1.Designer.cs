﻿namespace Pratica
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.ex1 = new System.Windows.Forms.Button();
            this.ex5 = new System.Windows.Forms.Button();
            this.ex4 = new System.Windows.Forms.Button();
            this.ex3 = new System.Windows.Forms.Button();
            this.ex2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ex1
            // 
            this.ex1.Location = new System.Drawing.Point(101, 52);
            this.ex1.Name = "ex1";
            this.ex1.Size = new System.Drawing.Size(150, 108);
            this.ex1.TabIndex = 0;
            this.ex1.Text = "Exercício 1";
            this.ex1.UseVisualStyleBackColor = true;
            this.ex1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ex5
            // 
            this.ex5.Location = new System.Drawing.Point(890, 52);
            this.ex5.Name = "ex5";
            this.ex5.Size = new System.Drawing.Size(150, 108);
            this.ex5.TabIndex = 1;
            this.ex5.Text = "Exercício 5";
            this.ex5.UseVisualStyleBackColor = true;
            this.ex5.Click += new System.EventHandler(this.ex5_Click);
            // 
            // ex4
            // 
            this.ex4.Location = new System.Drawing.Point(693, 52);
            this.ex4.Name = "ex4";
            this.ex4.Size = new System.Drawing.Size(150, 108);
            this.ex4.TabIndex = 2;
            this.ex4.Text = "Exercício 4";
            this.ex4.UseVisualStyleBackColor = true;
            this.ex4.Click += new System.EventHandler(this.ex4_Click);
            // 
            // ex3
            // 
            this.ex3.Location = new System.Drawing.Point(498, 52);
            this.ex3.Name = "ex3";
            this.ex3.Size = new System.Drawing.Size(150, 108);
            this.ex3.TabIndex = 3;
            this.ex3.Text = "Exercício 3";
            this.ex3.UseVisualStyleBackColor = true;
            this.ex3.Click += new System.EventHandler(this.ex3_Click);
            // 
            // ex2
            // 
            this.ex2.Location = new System.Drawing.Point(297, 52);
            this.ex2.Name = "ex2";
            this.ex2.Size = new System.Drawing.Size(150, 108);
            this.ex2.TabIndex = 4;
            this.ex2.Text = "Exercício 2";
            this.ex2.UseVisualStyleBackColor = true;
            this.ex2.Click += new System.EventHandler(this.ex2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(578, 248);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(131, 63);
            this.button1.TabIndex = 5;
            this.button1.Text = "Sair";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1277, 578);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.ex2);
            this.Controls.Add(this.ex3);
            this.Controls.Add(this.ex4);
            this.Controls.Add(this.ex5);
            this.Controls.Add(this.ex1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button ex1;
        private System.Windows.Forms.Button ex5;
        private System.Windows.Forms.Button ex4;
        private System.Windows.Forms.Button ex3;
        private System.Windows.Forms.Button ex2;
        private System.Windows.Forms.Button button1;
    }
}

