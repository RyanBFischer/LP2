﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {

        double peso, altura, IMC;
        string classificacao;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            IMC = peso / (altura * altura);
            IMC = Math.Round(IMC, 1);

            if (IMC < 18.5) { classificacao = "Magreza"; }
            else if (IMC >= 18.5 && IMC <= 24.9) { classificacao = "Normal"; }
            else if (IMC >= 25.0 && IMC <= 29.9) { classificacao = "Sobrepeso"; }
            else if (IMC >= 30.0 && IMC <= 39.9) { classificacao = "Obesidade (Grau II)"; }
            else { classificacao = "Obesidade Grave (Grau III)"; };

            mskdxIMC.Text = IMC.ToString();
            MessageBox.Show("Classificação: " + classificacao);
            
        }

        private void mskdxaltura_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void mskdxaltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskdxaltura.Text, out altura) || altura <= 0)
            {
                errorProvider1.SetError(mskdxaltura, "Número inválido");
                mskdxaltura.Focus();
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskdxaltura.Text = mskdxpeso.Text = mskdxIMC.Text = "";
            errorProvider1.Clear();
            errorProvider2.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
           if (MessageBox.Show("Deseja fechar?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void mskdxpeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskdxpeso.Text, out peso) || peso <= 0)
            {
                errorProvider1.SetError(mskdxpeso, "Número inválido");
                mskdxpeso.Focus();
            }
            else
            {
                errorProvider1.Clear();
            }
        }
        
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }


    }
}
