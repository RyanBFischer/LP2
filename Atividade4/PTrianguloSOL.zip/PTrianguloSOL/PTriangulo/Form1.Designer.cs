﻿namespace PTriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btncalc = new System.Windows.Forms.Button();
            this.lblvalorA = new System.Windows.Forms.Label();
            this.txtA = new System.Windows.Forms.TextBox();
            this.lblvalorB = new System.Windows.Forms.Label();
            this.lblvalorC = new System.Windows.Forms.Label();
            this.txtB = new System.Windows.Forms.TextBox();
            this.txtC = new System.Windows.Forms.TextBox();
            this.btnlimpar = new System.Windows.Forms.Button();
            this.btnsair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btncalc
            // 
            this.btncalc.Location = new System.Drawing.Point(55, 170);
            this.btncalc.Name = "btncalc";
            this.btncalc.Size = new System.Drawing.Size(106, 43);
            this.btncalc.TabIndex = 0;
            this.btncalc.Text = "Calcular";
            this.btncalc.UseVisualStyleBackColor = true;
            this.btncalc.Click += new System.EventHandler(this.btncalc_Click);
            // 
            // lblvalorA
            // 
            this.lblvalorA.AutoSize = true;
            this.lblvalorA.Location = new System.Drawing.Point(51, 48);
            this.lblvalorA.Name = "lblvalorA";
            this.lblvalorA.Size = new System.Drawing.Size(60, 20);
            this.lblvalorA.TabIndex = 1;
            this.lblvalorA.Text = "Lado A";
            this.lblvalorA.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtA
            // 
            this.txtA.Location = new System.Drawing.Point(149, 45);
            this.txtA.Name = "txtA";
            this.txtA.Size = new System.Drawing.Size(246, 26);
            this.txtA.TabIndex = 2;
            this.txtA.Validated += new System.EventHandler(this.txtA_Validated);
            // 
            // lblvalorB
            // 
            this.lblvalorB.AutoSize = true;
            this.lblvalorB.Location = new System.Drawing.Point(51, 83);
            this.lblvalorB.Name = "lblvalorB";
            this.lblvalorB.Size = new System.Drawing.Size(60, 20);
            this.lblvalorB.TabIndex = 3;
            this.lblvalorB.Text = "Lado B";
            this.lblvalorB.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblvalorC
            // 
            this.lblvalorC.AutoSize = true;
            this.lblvalorC.Location = new System.Drawing.Point(51, 119);
            this.lblvalorC.Name = "lblvalorC";
            this.lblvalorC.Size = new System.Drawing.Size(60, 20);
            this.lblvalorC.TabIndex = 4;
            this.lblvalorC.Text = "Lado C";
            // 
            // txtB
            // 
            this.txtB.Location = new System.Drawing.Point(149, 80);
            this.txtB.Name = "txtB";
            this.txtB.Size = new System.Drawing.Size(246, 26);
            this.txtB.TabIndex = 5;
            this.txtB.Validated += new System.EventHandler(this.txtB_Validated);
            // 
            // txtC
            // 
            this.txtC.Location = new System.Drawing.Point(149, 116);
            this.txtC.Name = "txtC";
            this.txtC.Size = new System.Drawing.Size(246, 26);
            this.txtC.TabIndex = 6;
            this.txtC.TextChanged += new System.EventHandler(this.txtC_TextChanged);
            this.txtC.Validated += new System.EventHandler(this.txtC_Validated);
            // 
            // btnlimpar
            // 
            this.btnlimpar.Location = new System.Drawing.Point(174, 170);
            this.btnlimpar.Name = "btnlimpar";
            this.btnlimpar.Size = new System.Drawing.Size(106, 43);
            this.btnlimpar.TabIndex = 7;
            this.btnlimpar.Text = "Limpar";
            this.btnlimpar.UseVisualStyleBackColor = true;
            this.btnlimpar.Click += new System.EventHandler(this.btnlimpar_Click);
            // 
            // btnsair
            // 
            this.btnsair.Location = new System.Drawing.Point(289, 170);
            this.btnsair.Name = "btnsair";
            this.btnsair.Size = new System.Drawing.Size(106, 43);
            this.btnsair.TabIndex = 8;
            this.btnsair.Text = "Sair";
            this.btnsair.UseVisualStyleBackColor = true;
            this.btnsair.Click += new System.EventHandler(this.btnsair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnsair);
            this.Controls.Add(this.btnlimpar);
            this.Controls.Add(this.txtC);
            this.Controls.Add(this.txtB);
            this.Controls.Add(this.lblvalorC);
            this.Controls.Add(this.lblvalorB);
            this.Controls.Add(this.txtA);
            this.Controls.Add(this.lblvalorA);
            this.Controls.Add(this.btncalc);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btncalc;
        private System.Windows.Forms.Label lblvalorA;
        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.Label lblvalorB;
        private System.Windows.Forms.Label lblvalorC;
        private System.Windows.Forms.TextBox txtB;
        private System.Windows.Forms.TextBox txtC;
        private System.Windows.Forms.Button btnlimpar;
        private System.Windows.Forms.Button btnsair;
    }
}

