﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        int ladoa, ladob, ladoc;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtA_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtA.Text, out ladoa))
            {
                MessageBox.Show("Erro no número");
                txtA.Focus();
            }
        }

        private void txtB_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtB.Text, out ladob))
            {
                MessageBox.Show("Erro no número");
                txtB.Focus();
            }
        }

        private void txtC_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtC_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtC.Text, out ladoc))
            {
                MessageBox.Show("Erro no número");
                txtC.Focus();
            }
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtA.Text = txtB.Text  = txtC.Text = String;
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            
            if ((MessageBox.Show("Quer realmente sair?", "Sair", MessageBoxButtons.YesNo, MessageBoxIcon.Question))==DialogResult.Yes) {
                this.Close();
            }
           
            
        }

        private void btncalc_Click(object sender, EventArgs e)
        {
            if (
                (
                    (ladoa > Math.Abs(ladob - ladoc)) &&
                    (ladoa < ladob + ladoc)
                    ) &&
                    (
                    (ladoa > Math.Abs(ladoa - ladoc)) &&
                    (ladob < ladoa + ladoc)
                    ) &&
                    (
                        (ladoc > Math.Abs(ladoa - ladob)) &&
                        (ladoc < ladoa + ladob)
                    ))
            {
                if (ladoa == ladob && ladob == ladoc)
                {
                    MessageBox.Show("Triângulo Equilátero");
                }else if (ladoa == ladob || ladoa == ladoc || ladob == ladoc)
                {
                    MessageBox.Show("Triângulo Isósceles");
                }else
                {
                    MessageBox.Show("Triângulo Escaleno");
                }
            } else
            {
                MessageBox.Show("Não é um triângulo", "BURRO");
            }
        }
    }
}
