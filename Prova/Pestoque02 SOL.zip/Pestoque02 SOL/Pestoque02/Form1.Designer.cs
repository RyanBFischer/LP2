﻿namespace Pestoque02
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.bttnVer = new System.Windows.Forms.Button();
            this.bttnLimp = new System.Windows.Forms.Button();
            this.listbxest = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // bttnVer
            // 
            this.bttnVer.Location = new System.Drawing.Point(212, 123);
            this.bttnVer.Name = "bttnVer";
            this.bttnVer.Size = new System.Drawing.Size(156, 51);
            this.bttnVer.TabIndex = 0;
            this.bttnVer.Text = "Verificar";
            this.bttnVer.UseVisualStyleBackColor = true;
            this.bttnVer.Click += new System.EventHandler(this.bttnVer_Click);
            // 
            // bttnLimp
            // 
            this.bttnLimp.Location = new System.Drawing.Point(212, 211);
            this.bttnLimp.Name = "bttnLimp";
            this.bttnLimp.Size = new System.Drawing.Size(156, 51);
            this.bttnLimp.TabIndex = 1;
            this.bttnLimp.Text = "Limpar";
            this.bttnLimp.UseVisualStyleBackColor = true;
            this.bttnLimp.Click += new System.EventHandler(this.bttnLimp_Click);
            // 
            // listbxest
            // 
            this.listbxest.FormattingEnabled = true;
            this.listbxest.ItemHeight = 20;
            this.listbxest.Location = new System.Drawing.Point(456, 58);
            this.listbxest.Name = "listbxest";
            this.listbxest.Size = new System.Drawing.Size(405, 344);
            this.listbxest.TabIndex = 2;
            this.listbxest.SelectedIndexChanged += new System.EventHandler(this.listbxest_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1251, 450);
            this.Controls.Add(this.listbxest);
            this.Controls.Add(this.bttnLimp);
            this.Controls.Add(this.bttnVer);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bttnVer;
        private System.Windows.Forms.Button bttnLimp;
        private System.Windows.Forms.ListBox listbxest;
    }
}

