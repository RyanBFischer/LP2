﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pestoque02
{
    public partial class Form1 : Form
    {
        string semana1, semana2, semana3, semana4;
        string mes1, mes2, mes3, mes4;

        private void bttnLimp_Click(object sender, EventArgs e)
        {
            listbxest.Items.Clear();
        }

        private void listbxest_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        string[,] produto = new string[4,4];

        private void bttnVer_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; i < 4; i++)
                {
                    produto[i, j] = Interaction.InputBox($"Digite o estoque da {i + 1}° Semana do {j + 1}° Mês", "Entrada de Dados");
                    listbxest.Items.Add($"Total Entradas do Produto na {i + 1}° semana: {produto[i, j]}");
                }

            }
            string soma = produto[0, 0] + produto[1, 0] + produto[2, 0] + produto[3, 0];
            listbxest.Items.Add($"Total Entradas do Produto no Mês: {soma}");
        }
        
        

        public Form1()
        {
            InitializeComponent();
        }

    }
}
